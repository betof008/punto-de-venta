import { IProduct } from "./IProduct";
export interface IProductCar {
  product:IProduct
  cant:number
}

export interface IData{
  nombre:string
  type:string
}
