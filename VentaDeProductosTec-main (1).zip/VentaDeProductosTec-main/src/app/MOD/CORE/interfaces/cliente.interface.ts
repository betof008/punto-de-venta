export interface ICliente{
    nombre: string;
    id: string;
}