import { IProductCar } from "./IProductCar";
export interface ICart { 
    cartList:IProductCar[]
    total:number
}
